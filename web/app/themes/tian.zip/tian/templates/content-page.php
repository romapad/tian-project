<section>
  <div class="wrap container" role="document">
    <div class="content row">  
      <div class="col-md-12">
<?php the_content(); ?>
      </div>
    </div><!-- /.content -->
  </div><!-- /.wrap -->     
</section>